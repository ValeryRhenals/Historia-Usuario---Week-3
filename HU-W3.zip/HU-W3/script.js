const texto = document.querySelector("input");
const boton = document.querySelector("button");
const lista = document.querySelector("#listaNotas");

// arreglo para guardar las notas
let notas = [];

// cargar notas guardadas en localStorage
const notasGuardadas = localStorage.getItem("notas");

if (notasGuardadas) {
    notas = JSON.parse(notasGuardadas);

    notas.forEach(function(nota) {
        crearNota(nota);
    });

    console.log("Notas cargadas:", notas.length);
}

// evento para agregar nota
boton.addEventListener("click", function(event) {
    event.preventDefault();

    const valorInput = texto.value;

    // validar input vacío
    if (valorInput === "") {
        alert("Escribe tu nota");
        return;
    }

    // guardar nota en el arreglo
    notas.push(valorInput);

    // guardar en localStorage
    localStorage.setItem("notas", JSON.stringify(notas));

    // crear nota en el DOM
    crearNota(valorInput);

    console.log("Se agregó la nota:", valorInput);

    // limpiar input
    texto.value = "";
    texto.focus();
});

// función para crear notas
function crearNota(textoNota) {

    // crear li
    const nuevaNota = document.createElement("li");

    // agregar texto
    nuevaNota.textContent = textoNota;

    // crear botón eliminar
    const botonEliminar = document.createElement("button");
    botonEliminar.textContent = "Eliminar";

    // agregar botón al li
    nuevaNota.appendChild(botonEliminar);

    // agregar li a la lista
    lista.appendChild(nuevaNota);

    // eliminar nota
    botonEliminar.addEventListener("click", function() {

        // eliminar del DOM
        lista.removeChild(nuevaNota);

        // eliminar del arreglo
        notas = notas.filter(function(nota) {
            return nota !== textoNota;
        });

        // actualizar localStorage
        localStorage.setItem("notas", JSON.stringify(notas));

        console.log("Se eliminó la nota:", textoNota);
    });
}